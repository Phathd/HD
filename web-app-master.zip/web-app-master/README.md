# web-app
<h3 style="text-transform:uppercase;font-weight:bold">Landing page</h3>

<img src="https://user-images.githubusercontent.com/39490493/60958267-44d3ce00-a330-11e9-91cf-353c1d7cb03a.png" width="1000" height="500" />
<img src="https://user-images.githubusercontent.com/39490493/60958274-48ffeb80-a330-11e9-9fb4-ee853974b887.png" width="1000" height="500" />
<img src="https://user-images.githubusercontent.com/39490493/60958334-61700600-a330-11e9-8d35-d10311e01bc4.png" width="1000" height="500" />


<h3 style="text-transform:uppercase;font-weight:bold">Shopping cart</h3>

<img height="500" width="1000" src="https://user-images.githubusercontent.com/39490493/60962674-fa0a8400-a338-11e9-91db-b5e70c005f72.PNG">

<h3 style="text-transform:uppercase;font-weight:bold">Product page</h3>

<img  height="500" width="1000" src="https://user-images.githubusercontent.com/39490493/60962675-fa0a8400-a338-11e9-9a97-c1afbeaa392b.PNG">
